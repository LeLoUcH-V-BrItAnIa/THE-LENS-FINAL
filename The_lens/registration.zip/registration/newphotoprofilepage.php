<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="display.css">
    <title>All Photographers Details</title>
</head>
<body>
<h1>Photographers</h1>
<form action="../index.php"><input type="submit" class="btn" value="Back to Home"></form>
    <div class="container"><?php include('displayphoto.php'); ?>
</div>
    
    
</body>
</html>
