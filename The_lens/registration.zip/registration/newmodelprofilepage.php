<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="display.css">
    <title>All Model Details</title>

</head>
<body>
    <h1>Models</h1> 
    <form action="../index.php"><input type="submit" class="btn" value="Back to Home"></form>
    <div class="container"><?php include('displaymodel.php'); ?>
  
</div>
    
    

</body>
</html>
