<?php

$con=mysqli_connect("localhost","root","","omprs");
// if($con){
//    echo "connection successful";
// }
// else{
//     die(mysqli_error($con=mysqli_connect("localhost","root","","votingsystem")));
// }

?>