<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            background: url(https://wallpapers.com/images/featured/4k-nature-ztbad1qj8vdjqe0p.jpg);
            background-repeat: no-repeat;
            background-size: cover;
           
        }
        h1{
            color: aliceblue;
            text-align: center;
            padding-top: 100px;
            font-weight: 900px;
            font-size: 80px;
            text-shadow: 5px 5px black;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        }

        p{
            color: aliceblue;
            text-align: center;
            /* padding-top: 100px; */
            font-weight: 900px;
            font-size: 40px;
            text-shadow: 5px 5px black;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        }
        h2{
            cursor: pointer;
            border: 2px;
            font-weight: 900px;
            font-size: 40px;
            color: aliceblue;
            text-align: center;
            transition: 3s;
           /* transition-delay: 1s; */
            /* text-shadow: 2px 2px black; */

        }
        h2:hover{
            transition: 3s;
            color:cyan;
            font-size: 100px;
            backdrop-filter: blur(2px);

          
        }
        input{
            text-align: center;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color: #f1f1f1;
            position: absolute;
            left: 90%;
            padding: 16px 30px;
  border: none;
  /* cursor: progress; */
  border-radius: 5px;
  text-align: center;
  
            
            
        }
        input:hover{
            background-color: black;
  color: white;
  
        }
    </style>
</head>
<body>
    <a href="../index.php"><input type="button" value="back to home"></a>
    <h1>Contact us</h1>
    <p>here</p>
    <h2>thelens@gmail.com<h2>
</body>
</html>